Feburary 7,2021 Ecological Disaster (Nanda Devi Glacier, IND: 7,108 m above sea level)

India most vulnerable country to climate change - HSBC report'2018 (Fragile Planet: Scoring climate risks around the world)

On this day, Nanda Devi glacier broke off in Uttarakhand’s Chamoli district
- triggering an avalanche and a deluge in the Alaknanda river system that washed away hydroelectric stations and trapped more than 100 labourers who are feared dead.

Is this the impact of Climate change (Global Warming)?

The below Satellite image analysis using the methodology of image segmentation shows that the Glacier cover in Nanda Devi has substantially decreased over the last 4 decades.
It has gone down from 43% in Year 1984 to 20% in Year 2022 (in relation to the captured area in image)

While UNFCC & global economies channelise their efforts towards a sustainable future for coming generations, it becomes so important for the developing economies like us to invest into Climate change Adaptation and Mitigation.
Global initiatives in terms of Net Zero Targets, Green Economy, Emission trading systems and Carbon tax are long term sustainable solutions, BUT Impacts of climate change are real & visible now.

Ecological disasters like these would continue to happen, Important is how we as individuals and economies build resilience towards these catastrophical impacts.